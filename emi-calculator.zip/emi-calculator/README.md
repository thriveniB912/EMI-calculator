# EMI Calculator
A simple EMI calculator built with React and Vite.