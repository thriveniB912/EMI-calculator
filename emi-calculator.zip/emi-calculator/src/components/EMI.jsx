import { useState } from 'react';
import './EMI.css';

export default function EMI() {
    const [show, setShow] = useState(false);
    const [result, setResult] = useState("EMI");
    const [emiForm, setEMIForm] = useState({
        loanAmount: '',
        interestRate: '',
        Tenure: ''
    });

    const handleChange = (event) => {
        const { name, value } = event.target;
        setEMIForm({ ...emiForm, [name]: value });
    };

    const onFormSubmit = (event) => {
        event.preventDefault();
        let loan = Number(emiForm.loanAmount);
        let rate = Number(emiForm.interestRate);
        let tenure = Number(emiForm.Tenure);

        if (!emiForm.loanAmount || !emiForm.interestRate || !emiForm.Tenure) {
            setShow(true);
            setResult("Please enter all values");
            return;
        }
        if (loan <= 0 || isNaN(loan)) {
            setShow(true);
            setResult("Please enter a valid loan amount");
            return;
        }
        if (tenure <= 0 || isNaN(tenure)) {
            setShow(true);
            setResult("Invalid tenure");
        } else {
            let temp = loan + (loan * (rate / 100));
            let emi = (temp / tenure).toFixed(2);
            setShow(true);
            setResult(`EMI : Rs. ${emi}/month`);
        }
    };

    return (
        <div className="emi-container">
            <form onSubmit={onFormSubmit}>
                <h1>EMI Calculator</h1>
                {show && <h2>{result}</h2>}
                <div className="field">
                    <i className="ri-money-rupee-circle-fill"></i>
                    <input type="number" name="loanAmount" onChange={handleChange} placeholder="Loan Amount" />
                </div>
                <div className="field">
                    <i className="ri-percent-fill"></i>
                    <input type="number" name="interestRate" onChange={handleChange} step="0.01" placeholder="Interest Rate" />
                </div>
                <div className="field">
                    <i className="ri-calendar-todo-line"></i>
                    <input type="number" name="Tenure" onChange={handleChange} placeholder="Tenure (months)" />
                </div>
                <button type="submit"><i className="ri-calculator-fill"></i> Calculate EMI</button>
            </form>
        </div>
    );
}
